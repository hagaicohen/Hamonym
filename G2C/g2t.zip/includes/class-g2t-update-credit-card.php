<?php
/**
 * All functionality related to users updating their credit card info, including sending email notifications once a month.
 *
 * @author Avishay Guttman
 * @date 7/8/2018
 */

namespace Planwize\Subscription;
use Planwize\G2t_Subscription;

class G2t_Update_Credit_Card{

	protected static $_instance;

	/**
	 * Create a singleton for the class.
	 *
	 * @return G2t_Update_Credit_Card
	 */
	public static function instance(){
		if ( null === self::$_instance ) {
			self::$_instance = new self;
		}

		return self::$_instance;
	}

	private function __construct() {
		add_action('g2t_check_expdates', array($this, 'send_notifications'));
	}


	/**
	 * Check users credit card expiration date monthly, send them notification when: two months left or one month left.
	 *
	 * @return void
	 */
	public function send_notifications(){
		set_time_limit(0); // WP Engine would probably ignore this

		$logger = G2t_Subscription::instance()->get_logger();

		$user_query = new \WP_User_Query(array(
			'meta_key' => 'subscriptions',
			'meta_compare' => 'EXISTS'
		));

		$users = $user_query->get_results();

		foreach ( $users as $user ) {
			$subscriptions = get_user_meta($user->ID, 'subscriptions', true);

			if ( count($subscriptions) > 0 ) foreach ( $subscriptions as $subscription ) {
			    $entry = \GFAPI::get_entry(rgar($subscription, 'entry_id'));

			    if ( rgar($entry, 'payment_status') != 'Active' ) {
			        continue;
                }

				$current_year = date('y', time());
				$current_month = date('m', time());
				$expdate = rgar($subscription, 'tranzila_cc_expdate');
				$exp_year = substr($expdate, -2);
				$exp_month = substr($expdate, 0, 2);

				// if it's not the same year or the expiration date passed
				if ( $current_year != $exp_year || $exp_month <= $current_month ) {
					continue;
				}

				if ( ((intval($exp_month) - intval($current_month)) == 2) || ((intval($exp_month) - intval($current_month)) == 1 ) ) {

					$campaign_name = rgar($subscription, 'campaign_id') == -1 ? false : get_post(rgar($subscription, 'campaign_id'))->post_title;
					$to = $user->user_email;
					$subject = __('Your credit card is about to expire', 'g2t');

					// set up the message
					ob_start();
					?>
					<div style="text-align: <?php echo is_rtl() ? 'right' : 'left' ?>;">
						<p><?php echo sprintf( __( 'Hi %s,', 'g2t' ), $user->display_name ) ?></p>
						<?php if ( ! $campaign_name ) : ?>
							<p>
								<?php echo sprintf( __( 'This is a friendly reminder that the credit card used for the subscription payment in Hamonym is about to expire.<br/>Please consider update it&apos;s details in <a href="%s" target="_blank">Your personal page</a>.', 'g2t' ), get_site_url() . '/g2t-personal-area' ) ?>
							</p>
						<?php else : ?>
							<p>
								<?php echo sprintf( __( 'This is a friendly reminder that the credit card used for the subscription payment in campaign "%s" is about to expire.<br/>Please consider update it&apos;s details in <a href="%s" target="_blank">Your personal page</a>.', 'g2t' ), $campaign_name, get_site_url() . '/g2t-personal-area' ) ?>
							</p>
						<?php endif; ?>
						<p><?php _e('Regards,<br/>Hamonym team.', 'g2t') ?></p>
					</div>
					<?php
					$message = ob_get_clean();
					$headers = array('Content-Type: text/html; charset=UTF-8');

					// fire the mail
					$mailed = wp_mail($to, $subject, $message, $headers);

					if ( ! $mailed ) {
						$logger->error('Failed to send credit card notification mail to ' . $user->user_email);
					}
				}
			}
		}
	}

	/**
     * Get tranzila iframe for where the context is updating the credit card.
     *
	 * @param $entry_id
	 * @param $iframe_width
	 * @param $iframe_height
	 *
	 * @return string
	 */
	public function get_update_tranzila_iframe($entry_id, $iframe_width, $iframe_height){
	    $g2t = gf_tranzila();

	    if ( is_null($g2t) ) {
	        return false;
        }

        $args = array();
		$tranzila_args_array = array();
	    $entry   = \GFAPI::get_entry($entry_id);
	    $form = \GFAPI::get_form($entry_id);
		$feed_id = gform_get_meta( $entry_id, 'g2t_subscription_feed_id' );
		$feed    = $g2t->get_feed( $feed_id );
		$tranzila_username = isset($feed['meta']['tranzilaUser']) ? $feed['meta']['tranzilaUser'] : false;

		if ( ! $tranzila_username ) {
		    return false;
        }

	    // get defaults args
        $tranzila_args = $g2t->get_tranzila_args($g2t->get_submission_data($feed, $form, $entry), $entry, $feed, 'updating_cc');

		// set only the args that we need
		$args['pdesc'] = 'Update credit card';
		$args['updating_cc'] = '1';
        $args['sum'] = '2';
        $args['contact'] = $tranzila_args['contact'];
        $args['email'] = $tranzila_args['email'];
        $args['tranmode'] = 'VK';
        $args['lang'] = $tranzila_args['lang'];
        $args['currency'] = $tranzila_args['currency'];
        $args['cred_type'] = '1';
        $args['custome'] = $tranzila_args['custome'];
        $args['customh'] = $tranzila_args['customh'];
		foreach ( $args as $key => $value ) {
			if ( ! empty($value) )
				$tranzila_args_array[] = '<input type="hidden" name="'.esc_attr($key).'" value="'.esc_attr($value).'" />';
		}

		ob_start();
		?>

        <form accept-charset="UTF-8" action="<?php echo esc_url( 'https://direct.tranzila.com/' . $tranzila_username . '/iframe.php' ) ?>" method="post" id="tranzila-form" target="tranzila_iframe">
			<?php echo implode('', $tranzila_args_array); ?>
            <input id="submit-tran-iframe" type="submit" value="submit" style="display: none;"/>
        </form>

        <iframe name="tranzila_iframe" id="tranzila_frame" width="<?php echo $iframe_width?>" height="<?php echo $iframe_height ?>" scrolling="no" style="border: none;"></iframe>

		<?php

        return ob_get_clean();
    }
}

G2t_Update_Credit_Card::instance();