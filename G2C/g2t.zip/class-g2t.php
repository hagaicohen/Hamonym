<?php
require_once( ABSPATH . 'wp-includes/class-phpass.php' );

if( !class_exists( 'WP_Http' ) )
    include_once( ABSPATH . WPINC. '/class-http.php' );

add_action( 'wp', array( 'G2T', 'maybe_thankyou_page' ), 5 );

GFForms::include_payment_addon_framework();

class G2T extends GFPaymentAddOn {
	protected $_version = GF_TRANZILA_VERSION;
	protected $_min_gravityforms_version = '1.9.3';
	protected $_slug = 'g2t';
	protected $_path = 'g2t/g2t.php';
	protected $_full_path = __FILE__;
	protected $_title = 'Gravity Forms Tranzila Add-On';
	protected $_short_title = 'Tranzila';
	protected $_supports_callbacks = true;
	protected $_requires_credit_card = false;
	protected $_enable_rg_autoupgrade = false;
	private $g2t_scripts_version = "1.1";
	private $production_url = 'https://direct.tranzila.com/';

	// Members plugin integration
	protected $_capabilities = array( 'gravityforms_tranzila', 'gravityforms_tranzila_uninstall' );

	// Permissions
	protected $_capabilities_settings_page = 'gravityforms_tranzila';
	protected $_capabilities_form_settings = 'gravityforms_tranzila';
	protected $_capabilities_uninstall = 'gravityforms_tranzila_uninstall';

	private static $_instance = null;

	// some constants from the former version for backwards compatibility
	const MIN_GF_VERSION = "1.6";
	const G2T_DB_VERSION = "1.1";
	const G2T_STYLES_VERSIONS = "1.1";
	const SOFTWARE_ID = "gravityformstranzila";

	public function __construct() {
		parent::__construct();
		$this->_title       = __( 'Gravity Forms Tranzila Add-On', 'g2t' );
		$this->_short_title = __( 'Tranzila', 'g2t' );

        add_filter( 'gform_export_fields', array( $this, 'add_custom_export_fields' ) );
        add_filter( 'gform_export_field_value', array( $this, 'set_custom_export_fields_values' ), 10, 4 );
    }

    /**
     * The single instance of the class.
     *
     * @return G2T|null
     */
    public static function get_instance() {
        if ( self::$_instance == null ) {
            self::$_instance = new G2T();
        }

        return self::$_instance;
    }

    private function __clone() {
    } /* do nothing */

    /**
     * Preform tasks only in the front end.
     */
    public function init_frontend() {
        parent::init_frontend();

        add_filter( 'gform_disable_post_creation', array( $this, 'delay_post' ), 10, 3 );
        add_filter( 'gform_disable_notification', array( $this, 'delay_notification' ), 10, 4 );
        add_action( 'gform_enqueue_scripts', array( $this, 'g2t_enqueue_scripts' ), 10, 2 );
        add_action( 'wp_enqueue_scripts', array( $this, 'g2t_enqueue_general_scripts' ), 10, 2 );
        add_filter( 'template_include', array( $this, 'add_personal_area_page' ) );
        add_action( 'wp_head', array( $this, 'break_out_of_iframe' ) );
        add_action( 'template_redirect', array( $this, 'redirect_after_updating_cc' ) );
    }

    /**
     * Preform tasks only in the admin.
     */
    public function init_admin() {
        parent::init_admin();
        add_action( 'admin_enqueue_scripts', array( $this, 'g2t_admin_enqueue_scripts' ) );
    }

    public function load_text_domain() {
        load_plugin_textdomain( 'g2t', false, basename( dirname( G2T_FILE ) ) . '/languages' );
    }

    /**
     * Settings pages
     *
     * @return array
     */
    public function plugin_settings_fields() {
        $lang_choices = array(
            array(
                'label' => esc_html__( 'English', 'g2t' ),
                'value' => 'us',
            ),
            array(
                'label' => esc_html__( 'Hebrew', 'g2t' ),
                'value' => 'il',
            ),
            array(
                'label' => esc_html__( 'Arabic', 'g2t' ),
                'value' => 'ar',
            ),
            array(
                'label' => esc_html__( 'Russian', 'g2t' ),
                'value' => 'ru',
            ),
            array(
                'label' => esc_html__( 'French', 'g2t' ),
                'value' => 'fr',
            ),
            array(
                'label' => esc_html__( 'Japanese', 'g2t' ),
                'value' => 'jp',
            ),
        );
        $fields       = array(
            array(
                'title'       => '',
                'description' => '',
                'fields'      => array(
                    array(
                        'label'   => esc_html__( 'Language', 'g2t' ),
                        'type'    => 'select',
                        'name'    => 'language',
                        'tooltip' => esc_html__( 'This is the language for the iframe', 'g2t' ),
                        'choices' => $lang_choices
                    ),
                ),
            )
        );

        return $fields;
    }

    /**
     * Save plugin settings only if the subbmit button was pressed.
     *
     * @return bool|void
     */
    public function maybe_save_plugin_settings() {

        if ( $this->is_save_postback() ) {

            check_admin_referer( $this->_slug . '_save_settings', '_' . $this->_slug . '_save_settings_nonce' );

            if ( ! $this->current_user_can_any( $this->_capabilities_settings_page ) ) {
                GFCommon::add_error_message( esc_html__( "You don't have sufficient permissions to update the settings.", 'g2t' ) );

                return false;
            }

            // store a copy of the previous settings for cases where action would only happen if value has changed
            $this->set_previous_settings( $this->get_plugin_settings() );

            $settings = $this->get_posted_settings();
            $sections = $this->plugin_settings_fields();
            $is_valid = $this->validate_settings( $sections, $settings );

            if ( $is_valid ) {
                $settings = $this->filter_settings( $sections, $settings );
                $this->update_plugin_settings( $settings );
                GFCommon::add_message( $this->get_save_success_message( $sections ) );
            } else {
                GFCommon::add_error_message( $this->get_save_error_message( $sections ) );
            }
        }

    }

    /**
     * Display message when the feed list is empty.
     *
     * @return string
     */
    public function feed_list_no_item_message() {
        $settings = $this->get_plugin_settings();

        if ( ! rgar( $settings, 'gf_settings_configured' ) ) {
            return sprintf( esc_html__( 'To get started, let\'s go configure your %sTranzila Settings%s!', 'g2t' ), '<a href="' . admin_url( 'admin.php?page=gf_settings&subview=' . $this->_slug ) . '">', '</a>' );
        } else {
            return parent::feed_list_no_item_message();
        }
    }

    /**
     * Initialize feed setting fields.
     *
     * @return array|mixed
     */
    public function feed_settings_fields() {
        $default_settings = parent::feed_settings_fields();

        // remove trial field for now
        if ( isset( $default_settings[1]['fields'][4]['name'] ) && $default_settings[1]['fields'][4]['name'] == 'trial' ) {
            unset( $default_settings[1]['fields'][4] );
        }

        //--add Tranzila account details
        $fields = array(
            array(
                'name'    => 'gf_currency',
                'label'   => esc_html__( 'Currency', 'g2t' ),
                'type'    => 'select',
                'choices' => array(
                    array(
                        'label' => esc_html__( 'ILS', 'g2t' ),
                        'value' => '1'
                    ),
                    array(
                        'label' => esc_html__( 'USD', 'g2t' ),
                        'value' => '2'
                    ),
                    array(
                        'label' => esc_html__( 'EUR', 'g2t' ),
                        'value' => '978'
                    ),
                    array(
                        'label' => esc_html__( 'GBP', 'g2t' ),
                        'value' => '826'
                    ),
                ),
                'tooltip' => esc_html__( "Your transactions currency", 'g2t' ),
            ),
            array(
                'name'     => 'tranzilaUser',
                'label'    => esc_html__( 'Tranzila Username', 'g2t' ),
                'type'     => 'text',
                'class'    => 'medium',
                'required' => true,
                'tooltip'  => '<h6>' . esc_html__( 'Tranzila Username', 'g2t' ) . '</h6>' . esc_html__( 'Enter the Tranzila username where payment should be received.', 'g2t' )
            ),
            array(
                'name'    => 'tranzila_notify_url',
                'label'   => esc_html__( 'Notify URL', 'g2t' ),
                'type'    => 'textarea',
                'class'   => 'tranzila-notify-url readonly',
                'rows'    => 3,
                'tooltip' => '<h6>' . esc_html__( 'Notify URL', 'g2t' ) . '</h6>' . esc_html__( 'This is the notify url you should set in <a href="https://direct.tranzila.com/merchant/">https://direct.tranzila.com/merchant/</a>. Do not share it with anyone.', 'g2t' )
            ),
            array(
                'name'     => 'tranzila_no_logo',
                'label'    => esc_html__( 'Hide "trusted" logos and tranzila logo', 'g2t' ),
                'type'     => 'checkbox',
                'required' => false,
                'choices'  => array(
                    array( 'label' => esc_html__( 'Hide', 'g2t' ), 'name' => 'tranzila_no_logo' ),
                ),
            ),

            array(
                'name'     => 'tranzila_bit_pay',
                'label'    => esc_html__( 'Use bit', 'g2t' ),
                'type'     => 'checkbox',
                'required' => false,
                'choices'  => array(
                    array( 'label' => esc_html__( 'Use bit', 'g2t' ), 'name' => 'tranzila_bit_pay' ),
                ),
            ),
            array(
                'name'     => 'tranzila_hide_cc',
                'label'    => esc_html__( 'Hide credit card', 'g2t' ),
                'type'     => 'checkbox',
                'required' => false,
                'choices'  => array(
                    array( 'label' => esc_html__( 'Hide credit card', 'g2t' ), 'name' => 'tranzila_hide_cc' ),
                ),
            ),
            array(
                'name'     => 'tranzila_ppnewwin',
                'label'    => esc_html__( 'PayPal', 'g2t' ),
                'type'     => 'checkbox',
                'required' => false,
                'choices'  => array(
                    array( 'label' => esc_html__( 'Enable PayPal', 'g2t' ), 'name' => 'tranzila_ppnewwin' ),
                ),
            ),
            array(
                'name'     => 'tranzila_j5',
                'label'    => esc_html__( 'J5 ', 'g2t' ),
                'type'     => 'checkbox',
                'required' => false,
                'choices'  => array(
                    array( 'label' => esc_html__( 'Enable J5', 'g2t' ), 'name' => 'tranzila_j5' ),
                ),
            ),
            array(
                'name'     => 'payments',
                'label'    => esc_html__( 'Payments ', 'g2t' ),
                'type'     => 'checkbox',
                'required' => false,
                'choices'  => array(
                    array( 'label' => esc_html__( 'Allow Payments ', 'g2t' ), 'name' => 'allow_payments' ),
                ),
            ),
            array(
                'name'     => 'tranzila_enable_handshake',
                'label'    => esc_html__( 'Enable handshake ', 'g2t' ),
                'type'     => 'checkbox',
                'required' => false,
                'choices'  => array(
                    array( 'label' => esc_html__( 'Enable handshake', 'g2t' ), 'name' => 'enable_handshake' ),
                ),
            ),
            array(
                'name'     => 'tranzilaTokensPW',
                'label'    => esc_html__( 'Tranzila Tokens Password', 'g2t' ),
                'type'     => 'text',
                'class'    => 'small',
                'required' => false,
                'tooltip'  => '<h6>' . esc_html__( 'Tranzila Tokens Password', 'g2t' ) . '</h6>' . esc_html__( 'Enter the Tranzila Tokens Password. (require for handshake)', 'g2t' )
            ),
            array(
                'name'     => 'max_payments',
                'label'    => esc_html__( 'Max Payments ', 'g2t' ),
                'type'     => 'select',
                'required' => false,
                'choices'  => $this->get_payments()
            ),
            array(
                'name'     => 'tranzilaIframeWidth',
                'label'    => esc_html__( 'Tranzila Iframe Width', 'g2t' ),
                'type'     => 'text',
                'class'    => 'medium',
                'required' => true,
                'tooltip'  => '<h6>' . esc_html__( 'Iframe Width', 'g2t' ) . '</h6>' . esc_html__( 'Enter Tranzila Iframe width', 'g2t' )
            ),
            array(
                'name'     => 'tranzilaIframeHeight',
                'label'    => esc_html__( 'Tranzila Iframe Height', 'g2t' ),
                'type'     => 'text',
                'class'    => 'medium',
                'required' => true,
                'tooltip'  => '<h6>' . esc_html__( 'Iframe Height', 'g2t' ) . '</h6>' . esc_html__( 'Enter Tranzila Iframe Height', 'g2t' )
            ),
        );

        $default_settings = parent::add_field_after( 'feedName', $fields, $default_settings );

        //--------------------------------------------------------------------------------------
        //-- add token terminal
        $fields           = array(
            array(
                'name'     => 'gf_tokens_username',
                'label'    => esc_html__( 'Tokens Username', 'g2t' ),
                'type'     => 'text',
                'class'    => 'medium',
                'required' => true,
                'tooltip'  => esc_html__( "Your tokens terminal username", 'g2t' ),
            ),
            array(
                'name'     => 'gf_tokens_password',
                'label'    => esc_html__( 'Tokens ISKAOT Password', 'g2t' ),
                'type'     => 'text',
                'class'    => 'medium',
                'required' => true,
                'tooltip'  => esc_html__( "Your tokens terminal ISKAOT password", 'g2t' ),
            ),
        );
        $default_settings = $this->add_field_before( 'recurringAmount', $fields, $default_settings );

        //--------------------------------------------------------------------------------------
        //--add Page Style, Continue Button Label, Cancel URL
        $fields = array(
            array(
                'name'    => 'options',
                'label'   => esc_html__( 'Options', 'g2t' ),
                'type'    => 'options',
                'tooltip' => '<h6>' . esc_html__( 'Options', 'g2t' ) . '</h6>' . esc_html__( 'Turn on or off the available Tranzila checkout options.', 'g2t' )
            ),
            array(
                'name'    => 'notifications',
                'label'   => esc_html__( 'Notifications', 'g2t' ),
                'type'    => 'notifications',
                'tooltip' => '<h6>' . esc_html__( 'Notifications', 'g2t' ) . '</h6>' . esc_html__( "Enable this option if you would like to only send out this form's notifications for the 'Form is submitted' event after payment has been received. Leaving this option disabled will send these notifications immediately after the form is submitted. Notifications which are configured for other events will not be affected by this option.", 'g2t' )
            ),
        );

        //Add post fields if form has a post
        $form = $this->get_current_form();
        if ( GFCommon::has_post_field( $form['fields'] ) ) {
            $post_settings = array(
                'name'    => 'post_checkboxes',
                'label'   => esc_html__( 'Posts', 'g2t' ),
                'type'    => 'checkbox',
                'tooltip' => '<h6>' . esc_html__( 'Posts', 'g2t' ) . '</h6>' . esc_html__( 'Enable this option if you would like to only create the post after payment has been received.', 'g2t' ),
                'choices' => array(
                    array(
                        'label' => esc_html__( 'Create post only when payment is received.', 'g2t' ),
                        'name'  => 'delayPost'
                    ),
                ),
            );

            if ( $this->get_setting( 'transactionType' ) == 'subscription' ) {
                $post_settings['choices'][] = array(
                    'label'    => esc_html__( 'Change post status when subscription is canceled.', 'g2t' ),
                    'name'     => 'change_post_status',
                    'onChange' => 'var action = this.checked ? "draft" : ""; jQuery("#update_post_action").val(action);',
                );
            }

            $fields[] = $post_settings;
        }


        $default_settings = $this->add_field_after( 'billingInformation', $fields, $default_settings );

        //-----------------------------------------------------------------------------------------

        //--get billing info section and add customer first/last name
        $billing_info   = parent::get_field( 'billingInformation', $default_settings );
        $billing_fields = $billing_info['field_map'];
        $add_first_name = $add_last_name = $add_phone = true;

        foreach ( $billing_fields as $mapping ) {
            //add first/last name/phone if it does not already exist in billing fields
            if ( $mapping['name'] == 'firstName' ) {
                $add_first_name = false;
            } else if ( $mapping['name'] == 'lastName' ) {
                $add_last_name = false;
            }

            if ( $mapping['name'] == 'phone' ) {
                $add_phone = false;
            }
        }

        if ( $add_phone ) {
            array_unshift( $billing_info['field_map'], array(
                'name'     => 'phone',
                'label'    => esc_html__( 'Phone', 'g2t' ),
                'required' => false
            ) );
        }

        array_unshift( $billing_info['field_map'], array(
            'name'     => 'campaignid',
            'label'    => esc_html__( 'Campaign ID', 'g2t' ),
            'required' => false
        ) );
        array_unshift( $billing_info['field_map'], array(
            'name'     => 'comments',
            'label'    => esc_html__( 'Comments', 'g2t' ),
            'required' => false
        ) );

        if ( $add_last_name ) {
            array_unshift( $billing_info['field_map'], array(
                'name'     => 'lastName',
                'label'    => esc_html__( 'Last Name', 'g2t' ),
                'required' => false
            ) );
        }
        if ( $add_first_name ) {
            array_unshift( $billing_info['field_map'], array(
                'name'     => 'firstName',
                'label'    => esc_html__( 'First Name', 'g2t' ),
                'required' => false
            ) );
        }


        $default_settings = parent::replace_field( 'billingInformation', $billing_info, $default_settings );
        //----------------------------------------------------------------------------------------------------

        //hide default display of setup fee, not used by Tranzila
        $default_settings = parent::remove_field( 'setupFee', $default_settings );

        // TODO complete trial feature
        /*$trial_period     = array(
                'name'    => 'trialPeriod',
                'label'   => esc_html__( 'Trial Period', 'g2t' ),
                'type'    => 'trial_period',
                'hidden'  => ! $this->get_setting( 'trial_enabled' ),
                'tooltip' => '<h6>' . esc_html__( 'Trial Period', 'g2t' ) . '</h6>' . esc_html__( 'Select the trial period length.', 'g2t' )
        );
        $default_settings = parent::add_field_after( 'trial', $trial_period, $default_settings );*/
        //-----------------------------------------------------------------------------------------

        //--Add Try to bill again after failed attempt.
        $recurring_retry  = array(
            'name'       => 'recurringRetry',
            'label'      => esc_html__( 'Recurring Retry', 'g2t' ),
            'type'       => 'checkbox',
            'horizontal' => true,
            'choices'    => array(
                array(
                    'label' => esc_html__( 'Try to bill again after failed attempt.', 'g2t' ),
                    'name'  => 'recurringRetry',
                    'value' => '1'
                )
            ),
            'tooltip'    => '<h6>' . esc_html__( 'Recurring Retry', 'g2t' ) . '</h6>' . esc_html__( 'Turn on or off whether to try to bill again after failed attempt.', 'g2t' )
        );
        $default_settings = parent::add_field_after( 'recurringTimes', $recurring_retry, $default_settings );

        //-----------------------------------------------------------------------------------------------------

        /**
         * Filter through the feed settings fields for the Tranzila feed
         *
         * @param array $default_settings The Default feed settings
         * @param array $form The Form object to filter through
         */
        return apply_filters( 'gform_tranzila_feed_settings_fields', $default_settings, $form );
    }

    /**
     * Get all payments 1-12 for the feed settings form.
     *
     * @return array
     */
    private function get_payments() {
        $return = array();

        for ( $i = 1; $i <= 12; $i ++ ) {
            $return[] = array( 'label' => $i, 'value' => $i );
        }

        return $return;
    }

    public function option_choices() {
        return false;
    }

    /**
     * Set supported billing interval for subscriptions.
     *
     * @return array
     */
    public function supported_billing_intervals() {

        $billing_cycles = array(
            'day'   => array( 'label' => esc_html__( 'day(s)', 'g2t' ), 'min' => 1, 'max' => 90 ),
            'week'  => array( 'label' => esc_html__( 'week(s)', 'g2t' ), 'min' => 1, 'max' => 52 ),
            'month' => array( 'label' => esc_html__( 'month(s)', 'g2t' ), 'min' => 1, 'max' => 24 ),
            'year'  => array( 'label' => esc_html__( 'year(s)', 'g2t' ), 'min' => 1, 'max' => 5 )
        );

        return $billing_cycles;
    }

    public function field_map_title() {
        return esc_html__( 'Tranzila Field', 'g2t' );
    }

    public function settings_options( $field, $echo = true ) {
        $checkboxes = array(
            'name'    => 'options_checkboxes',
            'type'    => 'checkboxes',
            'choices' => array(
                array(
                    'label' => esc_html__( 'Do not prompt buyer to include a shipping address.', 'g2t' ),
                    'name'  => 'disableShipping'
                ),
                array(
                    'label' => esc_html__( 'Do not prompt buyer to include a note with payment.', 'g2t' ),
                    'name'  => 'disableNote'
                ),
            )
        );

        $html = $this->settings_checkbox( $checkboxes, false );

        if ( $echo ) {
            echo $html;
        }

        return $html;
    }

    public function settings_custom( $field, $echo = true ) {
        ob_start();
        ?>

        <div id='gf_tranzila_custom_settings'>
            <?php do_action( 'gform_tranzila_add_option_group', $this->get_current_feed(), $this->get_current_form() ); ?>
        </div>

        <script type='text/javascript'>
            jQuery(document).ready(function () {
                jQuery('#gf_tranzila_custom_settings label.left_header').css('margin-left', '-200px');
            });
        </script>

        <?php
        $html = ob_get_clean();

        if ( $echo ) {
            echo $html;
        }

        return $html;
    }

    public function settings_notifications( $field, $echo = true ) {
        $checkboxes = array(
            'name'    => 'delay_notification',
            'type'    => 'checkboxes',
            'onclick' => 'ToggleNotifications();',
            'choices' => array(
                array(
                    'label' => esc_html__( "Send notifications for the 'Form is submitted' event only when payment is received.", 'g2t' ),
                    'name'  => 'delayNotification',
                ),
            )
        );

        $html = $this->settings_checkbox( $checkboxes, false );

        $html .= $this->settings_hidden( array(
            'name' => 'selectedNotifications',
            'id'   => 'selectedNotifications'
        ), false );

        $form                      = $this->get_current_form();
        $has_delayed_notifications = $this->get_setting( 'delayNotification' );
        ob_start();
        ?>

        <ul id="gf_tranzila_notification_container"
            style="padding-left:20px; margin-top:10px; <?php echo $has_delayed_notifications ? '' : 'display:none;' ?>">
            <?php
            if ( ! empty( $form ) && is_array( $form['notifications'] ) ) {
                $selected_notifications = $this->get_setting( 'selectedNotifications' );
                if ( ! is_array( $selected_notifications ) ) {
                    $selected_notifications = array();
                }

                $notifications = GFCommon::get_notifications( 'form_submission', $form );

                foreach ( $notifications as $notification ) {
                    ?>
                    <li class="gf_tranzila_notification">
                        <input type="checkbox" class="notification_checkbox" id="<?php echo $notification['id'] ?>"
                               value="<?php echo $notification['id'] ?>"
                               onclick="SaveNotifications();" <?php checked( true, in_array( $notification['id'], $selected_notifications ) ) ?> />
                        <label for="<?php echo $notification['id'] ?>" class="inline"
                               for="gf_tranzila_selected_notifications"><?php echo $notification['name']; ?></label>
                    </li>
                    <?php
                }
            }
            ?>
        </ul>
        <script type='text/javascript'>
            function SaveNotifications() {
                var notifications = [];
                jQuery('.notification_checkbox').each(function () {
                    if (jQuery(this).is(':checked')) {
                        notifications.push(jQuery(this).val());
                    }
                });
                jQuery('#selectedNotifications').val(jQuery.toJSON(notifications));
            }

            function ToggleNotifications() {

                var container = jQuery('#gf_tranzila_notification_container');
                var isChecked = jQuery('#delaynotification').is(':checked');

                if (isChecked) {
                    container.slideDown();
                    jQuery('.gf_tranzila_notification input').prop('checked', true);
                } else {
                    container.slideUp();
                    jQuery('.gf_tranzila_notification input').prop('checked', false);
                }

                SaveNotifications();
            }
        </script>
        <?php
        $html .= ob_get_clean();

        if ( $echo ) {
            echo $html;
        }

        return $html;
    }

    public function checkbox_input_change_post_status( $choice, $attributes, $value, $tooltip ) {
        $markup = $this->checkbox_input( $choice, $attributes, $value, $tooltip );

        $dropdown_field = array(
            'name'     => 'update_post_action',
            'choices'  => array(
                array( 'label' => '' ),
                array( 'label' => esc_html__( 'Mark Post as Draft', 'g2t' ), 'value' => 'draft' ),
                array( 'label' => esc_html__( 'Delete Post', 'g2t' ), 'value' => 'delete' ),

            ),
            'onChange' => "var checked = jQuery(this).val() ? 'checked' : false; jQuery('#change_post_status').attr('checked', checked);",
        );
        $markup         .= '&nbsp;&nbsp;' . $this->settings_select( $dropdown_field, false );

        return $markup;
    }

    /**
     * Save feed settings
     *
     * @param $feed_id
     * @param $form_id
     * @param $settings
     *
     * @return bool|int
     */
    public function save_feed_settings( $feed_id, $form_id, $settings ) {

        //--------------------------------------------------------
        //For backwards compatibility
        $feed = $this->get_feed( $feed_id );

        //Saving new fields into old field names to maintain backwards compatibility for delayed payments
        $settings['type'] = $settings['transactionType'];

        if ( isset( $settings['recurringAmount'] ) ) {
            $settings['recurring_amount_field'] = $settings['recurringAmount'];
        }

        $feed['meta'] = $settings;
        $feed         = apply_filters( 'gform_tranzila_save_config', $feed );

        //call hook to validate custom settings/meta added using gform_tranzila_action_fields or gform_tranzila_add_option_group action hooks
        $is_validation_error = apply_filters( 'gform_tranzila_config_validation', false, $feed );
        if ( $is_validation_error ) {
            //fail save
            return false;
        }

        $settings = $feed['meta'];

        //--------------------------------------------------------

        return parent::save_feed_settings( $feed_id, $form_id, $settings );
    }

    /**
     * Handling pre-submit confirmation and building tranzila iframe.
     *
     * @param array $confirmation
     * @param array $form
     * @param array $entry
     * @param bool $ajax
     *
     * @return array|string
     */
    public function confirmation( $confirmation, $form, $entry, $ajax ) {
        // if there is no reason to send the form to tranzila - don't send it
        $current_feed = $this->current_feed;
        if ( ! $current_feed ) {
            return $confirmation;
        }

        $tranzila_username = $current_feed['meta']['tranzilaUser'];
        if ( empty( $tranzila_username ) ) {
            return $confirmation;
        }

        //check whether this entry belong to another payment gateway (paypal...)
        $entry_id = $entry['id'];
        if ( ! $this->is_payment_gateway( $entry_id ) ) {
            //TODO handle case current entry/form already used to another payment-gateway
            return $confirmation;
        }

        $tranz_iframe_width = $tranz_iframe_height = 500;
        $loading_img_path   = plugins_url( "/images/loading.gif", __FILE__ );
        $feed               = $this->current_feed;
        $submission_data    = $this->current_submission_data;

        if ( is_numeric( $feed['meta']['tranzilaIframeWidth'] ) ) {
            $tranz_iframe_width = $feed['meta']['tranzilaIframeWidth'];
        }
        if ( is_numeric( $feed['meta']['tranzilaIframeHeight'] ) ) {
            $tranz_iframe_height = $feed['meta']['tranzilaIframeHeight'];
        }

        $tranzila_args_array = array();
        $tranzila_args       = $this->get_tranzila_args( $submission_data, $entry, $feed, 'payment' );
        $iframe_url_suffix = "";
        if(isset($tranzila_args["handshake_token"]) && $tranzila_args["handshake_token"]){
            $iframe_url_suffix = '?' . $tranzila_args["handshake_token"];
            unset($tranzila_args["handshake_token"]);
        }
        $this->debug( __METHOD__ . "Generated the following args to Tranzila: " . print_r( $tranzila_args, true ) ) . "\n";

        foreach ( $tranzila_args as $key => $value ) {
            if ( ! empty( $value ) ) {
                $tranzila_args_array[] = '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" />';
            }
        }

        ob_start();
        ?>

        <div id="gf_<?php echo $form['id'] ?>" class="gform_anchor"></div>
        <div id="g2t_waiting_msg">
            <b><?php _e( 'Your payment is in process. Please wait while we transfer you to a secure payment page.', 'g2t' ) ?></b>
            <img src="<?php echo $loading_img_path ?>" style='display:none; margin:auto; padding-left:10px;'
                 alt="loading-image"/>
        </div>

        <form accept-charset="UTF-8"
              action="<?php echo esc_url( 'https://direct.tranzila.com/' . $feed['meta']['tranzilaUser'] . '/iframenew.php' . $iframe_url_suffix ) ?>"
              method="post" id="tranzila-form" target="tranzila_iframe">
            <?php echo implode( '', $tranzila_args_array ); ?>
        </form>
        <div id="g2t_iframe_div" style="display: none">
            <iframe name="tranzila_iframe" id="tranzila_frame" width="<?php echo $tranz_iframe_width ?>"
                    height="<?php echo $tranz_iframe_height ?>" scrolling="no" style="border: none;"></iframe>
        </div>

        <?php
        $confirmation = ob_get_clean();
        if ( $ajax ) {
            ob_start();
            ?>
            <script>
                if (window.top == window){
                    jQuery(document).on('gform_confirmation_loaded', function () {
                            console.log('gform_confirmation_loaded running');
                            jQuery('#g2t_waiting_msg img').fadeToggle(1000);

                            document.getElementById("tranzila-form").setAttribute("target","tranzila_frame_top");
                            const parent = jQuery('#tranzila_frame').parent();
                            jQuery('#tranzila_frame').remove();
                            const newIframe = document.createElement("iframe");
                            newIframe.name = "tranzila_frame_top";
                            newIframe.id = "tranzila_frame_top";
                            newIframe.height = <?=  $tranz_iframe_height ?>;
                            newIframe.width = <?=  $tranz_iframe_width ?>;
                            newIframe.id = "tranzila_frame_top";
                            parent.append(newIframe);
                            jQuery("#tranzila-form").submit();

                            jQuery('#tranzila_frame_top').load(function(){
                                jQuery('#g2t_waiting_msg').hide();
                                jQuery(this).parent('div').slideDown();

                                function elementInViewport2(el) {
                                    let top = el.offsetTop;
                                    let left = el.offsetLeft;
                                    const width = el.offsetWidth;
                                    const height = el.offsetHeight;

                                    while(el.offsetParent) {
                                        el = el.offsetParent;
                                        top += el.offsetTop;
                                        left += el.offsetLeft;
                                    }

                                    return (
                                        top < (window.scrollY + window.innerHeight) &&
                                        left < (window.scrollX + window.innerWidth) &&
                                        (top + height) > window.scrollY &&
                                        (left + width) > window.scrollX
                                    );
                                }
                                const width = (window.innerWidth > 0) ? window.innerWidth : screen.width;

                                const activeTab = document.querySelector("#pills-campaign-tab > li > a.active");
                                if (activeTab && width <= 800){
                                    const activeTabContent = document.getElementById(activeTab.getAttribute('aria-controls'));
                                    activeTab.classList.remove("active",'show');
                                    activeTabContent.classList.remove("active",'show');
                                    const tranzila_frame_top = document.querySelector("#tranzila_frame_top");
                                    if (!elementInViewport2(tranzila_frame_top)) {
                                        jQuery([document.documentElement, document.body]).animate({
                                            scrollTop: jQuery(tranzila_frame_top).offset().top - 30
                                        }, 0);
                                    }
                                }


                            });
                        }
                    );
                }
            </script>
            <?php
            $confirmation .= ob_get_clean();
        }

        $this->debug( __METHOD__ . "Sending the following Request to Tranzila: " . $confirmation . "\n", true );

        return $confirmation;
    }

    /**
     * Prepare args to send to tranzila.
     *
     * @param $submission_data
     * @param $entry array The entry object
     * @param $feed array The feed object
     * @param $context string
     *
     * @return mixed
     */
    public function get_tranzila_args( $submission_data, $entry, $feed, $context = 'payment' ) {
        if ( $context == 'payment' ) {
            GFAPI::update_entry_property( $entry['id'], 'payment_status', 'Processing' );
        }

        $tranzila_args  = array();
        $payment_amount = rgar( $submission_data, 'payment_amount' );
        $bit         = ! empty( $feed['meta']['tranzila_bit_pay'] );
        $no_logo = ! empty( $feed['meta']['tranzila_no_logo'] );
        $hideCc         = ! empty( $feed['meta']['tranzila_hide_cc'] );
        $payPal         = ! empty( $feed['meta']['tranzila_ppnewwin'] );
        $j5             = ! empty( $feed['meta']['tranzila_j5'] );
        $allow_payments = ! empty( $feed['meta']['allow_payments'] ) && $feed['meta']['allow_payments'] == '1';
        $max_payments   = ! empty( $feed['meta']['max_payments'] ) ? $feed['meta']['max_payments'] : 0;
        $enable_handshake   = ! empty( $feed['meta']['enable_handshake'] ) && $feed['meta']['enable_handshake'] == '1';
        $token_password   = ! empty( $feed['meta']['tranzilaTokensPW'] ) ? $feed['meta']['tranzilaTokensPW'] : null;

        // collect contact details
        $first_name  = $this->get_billing_field_value( 'first_name', $feed, $entry );
        $last_name   = $this->get_billing_field_value( 'last_name', $feed, $entry );
        $email       = $this->get_billing_field_value( 'email', $feed, $entry );
        $address1    = $this->get_billing_field_value( 'address1', $feed, $entry );
        $address2    = $this->get_billing_field_value( 'address2', $feed, $entry );
        $zip         = $this->get_billing_field_value( 'zip', $feed, $entry );
        $city        = $this->get_billing_field_value( 'city', $feed, $entry );
        $phone       = $this->get_billing_field_value( 'phone', $feed, $entry );
        $campaign_id = $this->get_billing_field_value( 'campaignid', $feed, $entry );
        $comments    = $this->get_billing_field_value( 'comments', $feed, $entry );

        $currency_str = get_field( 'campaign_currency', $campaign_id );
        // $currency_str = rgar( $entry, 'currency' );

        $currency = $this->get_tranzila_currency_code($currency_str);


        if ( $context == 'payment' && $enable_handshake && $token_password) {
            $tranzila_username = $feed['meta']['tranzilaUser'];

            $handshake_token = $this->get_tranzila_handshake_token(
                $tranzila_username,
                $token_password,
                $payment_amount,
                $currency);

            if($handshake_token){
                $tranzila_args['handshake_token']  = $handshake_token;
            }
        }
        $tranzila_args['sum']      = $payment_amount;
        $tranzila_args['contact']  = $first_name . ' ' . $last_name;
        $tranzila_args['email']    = $email;
        $tranzila_args['address1'] = $address1;
        $tranzila_args['address2'] = $address2;
        $tranzila_args['city']     = $city;
        $tranzila_args['zip']      = $zip;
        $tranzila_args['lang']     = 'il';
        $tranzila_args['nologo'] = $no_logo ? 1 : 0;

        $tranzila_args['phone']      = $phone;
        $tranzila_args['campaignid'] = $campaign_id;
        $tranzila_args['comments']   = $comments;

        // aviad priel edit
        $tranzila_args['first_name'] = $first_name;
        $tranzila_args['last_name']  = $last_name;

        // Standing order
        $standing_order = get_field( "standing_order", $campaign_id, 'no' );

        if ( $standing_order != 'no' ) {
            if ( $standing_order == 'yes_must_month' ) {
                $tranzila_args['recur_transaction'] = '4_approved';
            } elseif ( $standing_order == 'yes_must_3months' ) {
                $tranzila_args['recur_transaction'] = '5_approved';
            } elseif ( $standing_order == 'yes_must_year' ) {
                $tranzila_args['recur_transaction'] = '7_approved';
            } elseif ( $standing_order == 'yes_choose_month' ) {
                $tranzila_args['recur_transaction'] = '4';
            } elseif ( $standing_order == 'yes_choose_3months' ) {
                $tranzila_args['recur_transaction'] = '5';
            } elseif ( $standing_order == 'yes_choose_year' ) {
                $tranzila_args['recur_transaction'] = '7';
            }
        }
        // bit
        $tranzila_args['bit_pay'] =  $bit ? 1: 0;
        $tranzila_args['hide_cc'] =  $hideCc ? 1: 0;

        // payPal
        if ( $payPal ) {
            $tranzila_args['ppnewwin'] = 2;  //  for paypal support
        }
        // j5
        if ( $j5 ) {
            $tranzila_args['tranmode'] = "V";
        } else {
            $tranzila_args['tranmode'] = "A";
        }

        // Payments
        if ( $allow_payments && (int) $max_payments > 1 && $standing_order == 'no' ) {
            $tranzila_args['cred_type'] = '8';
            $tranzila_args['maxpay']    = intval( $max_payments );
        }

        // TODO this is quick-and-dirty solution for setting campaign language - please make pretty.
        $camp_lang = get_field( "campaign_language", $campaign_id );
        switch ( $camp_lang ) {
            case "en_US":
                $tranzila_args['lang'] = 'us';
        }



        if ( is_rtl() ) {
            $currency_str = 'ש"ח';
        }

        $tranzila_args['currency'] = $currency;
        $item_loop                 = 0;

        $tranzila_args['pdesc'] = "";
        if ( count( $submission_data['line_items'] ) > 0 ) {
            foreach ( $submission_data['line_items'] as $item ) {
                if ( $item['quantity'] ) {
                    $item_name = $item['name'];
                    if ( $item_loop ) {
                        $tranzila_args['pdesc'] .= " , ";
                    }
                    $pdesc_price            = $item['unit_price'] . " " . $currency_str;
                    $tranzila_args['pdesc'] .= $item['quantity'] . " " . $item_name . ": " . $pdesc_price;
                    $item_loop ++;
                }
            }
        }

        // subscription
        if ( $feed['meta']['transactionType'] == 'subscription' ) {
            $tranzila_args['transaction_type'] = 'subscription';
            if ( $j5 ) {
                $tranzila_args['tranmode'] = 'VK';
            } else {
                $tranzila_args['tranmode'] = 'AK';
            }
        }

        $tranzila_args['custome'] = $entry['id'];
        $tranzila_args['customh'] = wp_hash( $entry['id'] );

        if ( is_user_logged_in() ) {
            $tranzila_args['current_user_id'] = get_current_user_id();
        }


        return apply_filters( 'g2t_tranzila_args', $tranzila_args, $this, $submission_data, $entry, $feed );
    }

    /**
     * @param string $tranzila_username
     * @param string $token_password
     * @param string|int $sum
     * @param string|int $currency
     * @return string thtk=<the token>
     */
    private function get_tranzila_handshake_token(string     $tranzila_username,
                                                  string     $token_password,
                                                             $sum,
                                                             $currency):string{
        $tranzila_api_url = 'https://secure5.tranzila.com/cgi-bin/tranzila71dt.cgi';
        $query_parameters = [
            "supplier" => $tranzila_username, // terminal name
            "sum" => $sum,  //Transaction sum
            "currency" => $currency,  // Type of currency 1 NIS, 2 USD, 978 EUR, 826 GBP, 392 JPY
            "TranzilaPW" => $token_password,  //Transaction sum
            "op" => '1' //Required for handshake
        ];

        $http_client = new WP_Http();
        $response = $http_client->post($tranzila_api_url,[
            'body' => $query_parameters
        ]);
        if($response instanceof WP_Error){
            $this->debug( __METHOD__ . "failed generate handshake token error:" . $response->get_error_message() );
            return "";
        }
        $data = json_decode($response['body']);
        return $response['body'];
    }

    private function get_tranzila_currency_code($currency_str):string{

        // $currency_str = rgar( $entry, 'currency' );
        switch ( $currency_str ) {
            case 'USD':
                return '2';
            case 'EUR':
                return'978';
            case 'BGP':
                return '826';
            case 'ILS':
            default:
                return  '1';
        }
    }
    /**
     * Get billing field value by field name.
     *
     * @param $name
     * @param $feed
     * @param $entry
     *
     * @return mixed|null|string
     */
    private function get_billing_field_value( $name, $feed, $entry ) {
        foreach ( $this->get_customer_fields() as $field ) {
            if ( $field['name'] == $name ) {
                $field_id = $feed['meta'][ $field['meta_name'] ];
                $value    = rgar( $entry, $field_id );

                return $value;
            }
        }

        return '';
    }

    public static function maybe_thankyou_page() {
        $instance = self::get_instance();

        if ( ! $instance->is_gravityforms_supported() ) {
            return;
        }

        if ( $str = rgget( 'gf_tranzila_return' ) ) {
            $str = base64_decode( $str );

            parse_str( $str, $query );
            if ( wp_hash( 'ids=' . $query['ids'] ) == $query['hash'] ) {
                list( $form_id, $lead_id ) = explode( '|', $query['ids'] );

                $form = GFAPI::get_form( $form_id );
                $lead = GFAPI::get_entry( $lead_id );

                if ( ! class_exists( 'GFFormDisplay' ) ) {
                    require_once( GFCommon::get_base_path() . '/form_display.php' );
                }

                $confirmation = GFFormDisplay::handle_confirmation( $form, $lead, false );

                if ( is_array( $confirmation ) && isset( $confirmation['redirect'] ) ) {
                    header( "Location: {$confirmation['redirect']}" );
                    exit;
                }

                GFFormDisplay::$submission[ $form_id ] = array(
                    'is_confirmation'      => true,
                    'confirmation_message' => $confirmation,
                    'form'                 => $form,
                    'lead'                 => $lead
                );
            }
        }
    }

    public function get_customer_fields() {
        return array(
            array( 'name' => 'first_name', 'label' => 'First Name', 'meta_name' => 'billingInformation_firstName' ),
            array( 'name' => 'last_name', 'label' => 'Last Name', 'meta_name' => 'billingInformation_lastName' ),
            array( 'name' => 'email', 'label' => 'Email', 'meta_name' => 'billingInformation_email' ),
            array( 'name' => 'address1', 'label' => 'Address', 'meta_name' => 'billingInformation_address' ),
            array( 'name' => 'address2', 'label' => 'Address 2', 'meta_name' => 'billingInformation_address2' ),
            array( 'name' => 'city', 'label' => 'City', 'meta_name' => 'billingInformation_city' ),
            array( 'name' => 'state', 'label' => 'State', 'meta_name' => 'billingInformation_state' ),
            array( 'name' => 'zip', 'label' => 'Zip', 'meta_name' => 'billingInformation_zip' ),
            array( 'name' => 'country', 'label' => 'Country', 'meta_name' => 'billingInformation_country' ),
            array( 'name' => 'phone', 'label' => 'Phone', 'meta_name' => 'billingInformation_phone' ),
            array( 'name' => 'campaignid', 'label' => 'Campaign ID', 'meta_name' => 'billingInformation_campaignid' ),
            array( 'name' => 'comments', 'label' => 'Comments', 'meta_name' => 'billingInformation_comments' ),
        );
    }

    public function convert_interval( $interval, $to_type ) {
        //convert single character into long text for new feed settings or convert long text into single character for sending to tranzila
        if ( empty( $interval ) ) {
            return '';
        }

        if ( $to_type == 'text' ) {
            //convert single char to text
            switch ( strtoupper( $interval ) ) {
                case 'D' :
                    $new_interval = 'day';
                    break;
                case 'W' :
                    $new_interval = 'week';
                    break;
                case 'M' :
                    $new_interval = 'month';
                    break;
                case 'Y' :
                    $new_interval = 'year';
                    break;
                default :
                    $new_interval = $interval;
                    break;
            }
        } else {
            //convert text to single char
            switch ( strtolower( $interval ) ) {
                case 'day' :
                    $new_interval = 'D';
                    break;
                case 'week' :
                    $new_interval = 'W';
                    break;
                case 'month' :
                    $new_interval = 'M';
                    break;
                case 'year' :
                    $new_interval = 'Y';
                    break;
                default :
                    $new_interval = $interval;
                    break;
            }
        }

        return $new_interval;
    }

    public function delay_post( $is_disabled, $form, $entry ) {

        $feed            = $this->get_payment_feed( $entry );
        $submission_data = $this->get_submission_data( $feed, $form, $entry );

        if ( ! $feed || empty( $submission_data['payment_amount'] ) ) {
            return $is_disabled;
        }

        return ! rgempty( 'delayPost', $feed['meta'] );
    }

    public function delay_notification( $is_disabled, $notification, $form, $entry ) {

        $feed            = $this->get_payment_feed( $entry );
        $submission_data = $this->get_submission_data( $feed, $form, $entry );

        if ( ! $feed || empty( $submission_data['payment_amount'] ) ) {
            return $is_disabled;
        }

        $selected_notifications = is_array( rgar( $feed['meta'], 'selectedNotifications' ) ) ? rgar( $feed['meta'], 'selectedNotifications' ) : array();

        return isset( $feed['meta']['delayNotification'] ) && in_array( $notification['id'], $selected_notifications ) ? true : $is_disabled;
    }


    /**
     * Enqueue front end scripts onlt for relevant froms.
     *
     * @param $form
     * @param $is_ajax
     */
    public function g2t_enqueue_scripts( $form, $is_ajax ) {
        $feed = $this->current_feed;

        if ( $feed !== false && !$is_ajax ) {
            wp_enqueue_script( "g2t_enqueue_script", plugins_url( "js/gravityformstranzila.js", __FILE__ ), array( "jquery" ), $this->g2t_scripts_version );
        }
    }

    /**
     * @hooked wp_enqueue_scripts
     */
    public function g2t_enqueue_general_scripts() {
        if ( is_page( 'g2t-personal-area' ) ) {
            wp_enqueue_style( 'g2t-personal-area-style', plugins_url( 'css/personal-area.css', __FILE__ ), array(), $this->g2t_scripts_version );
            wp_enqueue_script( 'g2t-personal-area-script', plugins_url( 'js/personal-area.js', __FILE__ ), array( 'jquery' ), $this->g2t_scripts_version, true );
        }
    }

    /**
     * Enqueue back end scripts.
     */
    public function g2t_admin_enqueue_scripts() {
        if ( ( isset( $_GET['subview'] ) && $_GET['subview'] == 'g2t' )
            || ( isset( $_GET['page'] ) && $_GET['page'] == 'gf_entries' ) ) {
            wp_enqueue_style( 'g2t-admin-style', plugins_url( 'css/admin.css', G2T_FILE ), array(), '4216721' );
        }
    }

    public function scripts() {
        $scripts = array(
            array(
                'handle'   => 'admin-js',
                'src'      => $this->get_base_url() . '/js/admin.js',
                'version'  => $this->_version,
                'deps'     => array( 'jquery' ),
                'callback' => array( $this, 'localize_scripts' ),
                'enqueue'  => array(
                    array( 'admin_page' => array( 'form_settings', 'plugin_settings' ) ),
                    array( 'query' => 'page=gf_entries&view=entry' )
                )
            ),
        );

        return array_merge( parent::scripts(), $scripts );
    }

    public function localize_scripts( $a, $b ) {
        $data = array( 'admin_url' => admin_url( "admin-ajax.php" ) );
        wp_localize_script( 'license_js', 'php_data', $data );

        wp_localize_script( 'admin-js', 'adminLocalized', array(
            'security'                     => wp_create_nonce( 'admin_reactivate_subscription' ),
            'security_cancel_subscription' => wp_create_nonce( 'cancel_subscription' ),
            'security_resume_subscription' => wp_create_nonce( 'resume_subscription' ),
            'notify_url'                   => $this->get_notify_url()
        ) );
    }

    /**
     * Break out of iframe after payment.
     */
    public function break_out_of_iframe() {

        // Avishay's modi:
        ob_start();
        ?>

        <script type="text/javascript">
            console.log('break_out_of_iframe');
            if (top.location !== self.location) {
                top.location = self.location.href;
            }
        </script>

        <?php
        $var_sScript = ob_get_contents();

        ob_get_clean();
        /*
         * To alter the script output just use
         * add_filter('break_out_of_iframe', 'your_function');
         */
        $var_sScript = apply_filters( 'break_out_of_iframe', $var_sScript );

        echo $var_sScript;

        return;
    }


    /**
     * Processing tranzila IPN.
     * This method being called once the notify URL is visited.
     *
     * @return array|bool|WP_Error
     */
    public function callback() {


        if ( ! $this->is_gravityforms_supported() ) {
            return false;
        }

        $this->debug( __METHOD__ . '(): IPN request received => ' . print_r( $_POST, true ) );

        $entry = $this->get_entry( rgpost( 'custome' ), rgpost( 'customh' ) );

        // if it's a request to update credit card
        if ( isset( $_POST['updating_cc'] ) && $_POST['updating_cc'] == '1' ) {
            $this->process_update_credit_card_ipn_req( $_POST, $entry );

            return false;
        }

        // ignore orphan IPN messages (ones without an entry)
        if ( ! $entry ) {
            $this->debug( __METHOD__ . '(): Entry could not be found. Aborting.' );

            return false;
        }

        if($entry["payment_status"] == "Paid"){
            $this->debug( __METHOD__ . '(): duplicate callback found $entry already paid benid = ' . $_POST['benid']  );
            return true;
        }

        // TODO do we really need to log this?
        /*$this->debug( __METHOD__ . '(): Entry has been found => ' . print_r( $entry, true ) );*/

        if ( $entry['status'] == 'spam' ) {
            $this->debug( __METHOD__ . '(): Entry is marked as spam. Aborting.' );

            return false;
        }

        // getting feed related to this IPN
        $feed = $this->get_payment_feed( $entry );

        // ignore IPN messages from forms that are no longer configured with the Tranzila add-on
        if ( ! $feed || ! rgar( $feed, 'is_active' ) ) {
            $this->log_error( __METHOD__ . "(): Form no longer is configured with Tranzila Addon. Form ID: {$entry['form_id']}. Aborting." );

            return false;
        }

        $this->debug( __METHOD__ . '(): Processing IPN... ' );
        // TODO find out what are 'parent_txn_id', 'pending_reason' 'mc_amount3' in tranzila. Most of them are for subscription payment type.

        $action = $this->process_ipn( $entry, $_POST );

        if ( is_array( $action ) ) {
            $this->debug( __METHOD__ . '(): Finish build action: ' . print_r( $action, true ) );
        }

        // Hook for when the payment is complete.
        if ( $_POST['Response'] == '000' && $_POST['sum'] > 0 ) {
            // Start
            if ( isset( $entry['id'] ) ) {
                //gf_gae_send_hit( $entry['id'] );
            }
            // End
            $this->complete_payment( $entry, $action );
            $post_tranzila = $_POST;
            GFAPI::update_entry_property( $entry['id'], 'payment_status', 'Paid' );
            do_action( 'gform_tranzila_payment_complete', $post_tranzila, $entry, $feed );

            // if we have subscription payment
            if ( isset( $action['transaction_type'] ) && $action['transaction_type'] == 'subscription' ) {
                GFAPI::update_entry_property( $entry['id'], 'payment_status', 'Active' );
                do_action( 'signup_subscription_payment_complete', $post_tranzila, $entry, $feed );
            } else {
                do_action( 'signup_regular_payment_complete', $post_tranzila, $entry, $feed );
            }
        }

        if ( rgempty( 'entry_id', $action ) ) {
            return false;
        }

        return $action;
    }

    /**
     * Process the IPN we got from tranzila.
     *
     * @param $entry
     * @param $post_data
     *
     * @return array
     * @author Avishay Guttman
     * @date 28/6/2018
     *
     */
    private function process_ipn( $entry, $post_data ) {
        $this->save_tranzila_response( $entry['id'], $post_data );

        $action = $this->build_action( $entry, $post_data );

        return $action;
    }

    /**
     * Process request to update credit card details.
     *
     * @param $post
     * @param $entry
     */
    private function process_update_credit_card_ipn_req( $post, $entry ) {
        $this->debug( __METHOD__ . '(): Start processing update request for entry #' . $entry['id'] );

        // success
        if ( isset( $post['Response'] ) && $post['Response'] == '000' ) {
            gform_update_meta( $entry['id'], 'TranzilaTK', $post['TranzilaTK'] );
            gform_update_meta( $entry['id'], 'expdate', $post['expmonth'] . $post['expyear'] );
            $this->debug( __METHOD__ . "(): Update credit card for entry {$entry['id']} complete" );
            $this->add_note( $entry['id'], __( 'User updated his credit card details.', 'g2t' ), 'success' );

            return;
        }

        // failed
        $this->debug( __METHOD__ . '(): Failed to update credit card details. Response from tranzila => ' . print_r( $post, true ) );
    }

    /**
     * Save the response we get from tranzila as entry meta.
     *
     * @param $entry_id
     * @param $post_data
     *
     * @author Avishay Guttman
     * @date 28/6/2018
     *
     */
    private function save_tranzila_response( $entry_id, $post_data ) {

        if ( ! empty( $post_data['TranzilaTK'] ) ) {
            gform_update_meta( $entry_id, 'TranzilaTK', $post_data['TranzilaTK'] );
        }
        if ( ! empty( $post_data['expmonth'] ) && ! empty( $post_data['expyear'] ) ) {
            gform_update_meta( $entry_id, 'expdate', $post_data['expmonth'] . $post_data['expyear'] );
        }
        if ( ! empty( $post_data['contact'] ) ) {
            gform_update_meta( $entry_id, 'contact', $post_data['contact'] );
        }
        if ( ! empty( $post_data['myid'] ) ) {
            gform_update_meta( $entry_id, 'contact_id', $post_data['myid'] );
        }
        if ( ! empty( $post_data['sum'] ) ) {
            gform_update_meta( $entry_id, 'sum', $post_data['sum'] );
        }
        if ( ! empty( $post_data['tranmode'] ) ) {
            gform_update_meta( $entry_id, 'tranmode', $post_data['tranmode'] );
        }
        if ( ! empty( $post_data['cardtype'] ) ) {
            gform_update_meta( $entry_id, 'card_type', $post_data['cardtype'] );
        }
        if ( ! empty( $post_data['ipsp'] ) && (int) $post_data['ipsp'] == 1 ) {
            gform_update_meta( $entry_id, 'express_terminal', 1 );
        }
    }

    /**
     * Build associative array that we going to return in the callback, based on the transaction type.
     *
     * @param $entry
     * @param $post_data
     *
     * @return array
     * @see https://docs.gravityforms.com/gfpaymentaddon/#callback-
     *
     * @author Avishay Guttman
     * @date 28/6/2018
     *
     */
    private function build_action( $entry, $post_data ) {
        $action = array();
        $action['test'] = "aviad";

        // if it's a subscription transaction
        if ( isset( $post_data['transaction_type'] ) && $post_data['transaction_type'] == 'subscription' ) {
            $action['id']               = $post_data['index'];
            $action['transaction_type'] = 'subscription';
            $action['transaction_id']   = $post_data['index'];
            $action['type']             = ( isset( $post_data['Response'] ) && $post_data['Response'] == '000' ) ? 'create_subscription' : 'fail_subscription_payment';
            $action['subscription_id']  = $post_data['index'];
            $action['amount']           = $post_data['sum'];
            $action['entry_id']         = $entry['id'];
            $action['payment_method']   = 'Tranzila';

            // save the number of payments
            gform_add_meta( $entry['id'], 'payments_so_far', 1 );

            return $action;
        }

        // if it's a regular transaction
        if ( isset( $post_data['Response'] ) && $post_data['Response'] == '000' ) {
            $action['id']               = $post_data['index'] . '_' . $post_data['Response'];
            $action['type']             = 'complete_payment';
            $action['transaction_id']   = $post_data['index'];
            $action['amount']           = $post_data['sum'];
            $action['entry_id']         = $entry['id'];
            $action['payment_date']     = gmdate( 'y-m-d H:i:s' );
            $action['payment_method']   = 'Tranzila';
            $action['ready_to_fulfill'] = ! $entry['is_fulfilled'] ? true : false;

            // check if the amount sent is valid
            if ( ! $this->is_valid_initial_payment_amount( $entry['id'], $post_data['sum'] ) ) {
                //create note and transaction
                $this->debug( __METHOD__ . '(): Payment amount does not match product price. Entry will not be marked as Approved.' );
                GFPaymentAddOn::add_note( $entry['id'], sprintf( __( 'Payment amount (%s) does not match product price. Entry will not be marked as Approved. Transaction Id: %s', 'g2t' ), GFCommon::to_money( $post_data['sum'], $entry['currency'] ), $post_data['index'] ) );
                GFPaymentAddOn::insert_transaction( $entry['id'], 'payment', $post_data['index'], $post_data['sum'] );

                $action['abort_callback'] = true;
            }

            return $action;
        }

        // transaction failed
        $action['id']             = $post_data['index'] . '_' . $post_data['Response'];
        $action['type']           = 'fail_payment';
        $action['transaction_id'] = $post_data['index'];
        $action['entry_id']       = $entry['id'];
        $action['amount']         = $post_data['sum'];
        $amount_formatted         = GFCommon::to_money( $action['amount'], $entry['currency'] );
        $action['note']           = sprintf( __( 'Transaction Failed. Amount: %s. Transaction Id: %s. Error Code: %s. Contact Tranzila to learn more about this error.', 'g2t' ), $amount_formatted, $action['transaction_id'], $post_data['Response'] );

        return $action;
    }

    public function get_payment_feed( $entry, $form = false ) {

        $feed = parent::get_payment_feed( $entry, $form );

        if ( empty( $feed ) && ! empty( $entry['id'] ) ) {
            //looking for feed created by legacy versions
            $feed = $this->get_tranzila_feed_by_entry( $entry['id'] );
        }

        $feed = apply_filters( 'gform_tranzila_get_payment_feed', $feed, $entry, $form ? $form : GFAPI::get_form( $entry['form_id'] ) );

        return $feed;
    }

    /**
     * Get feed by entry ID.
     * If there are more then one feed, return the first one.
     *
     * @param $entry_id
     *
     * @return array|bool|null|object
     */
    private function get_tranzila_feed_by_entry( $entry_id ) {
        $feed_id = gform_get_meta( $entry_id, 'tranzila_feed_id' );
        $feed    = $this->get_feed( $feed_id );

        return ! empty( $feed ) ? $feed : false;
    }

    /**
     * Get entry while processing IPN message, check that it was valid and was creating using GF.
     *
     * @param $custom_field_e
     * @param $custom_field_h
     *
     * @return array|bool|WP_Error
     */
    public function get_entry( $custom_field_e, $custom_field_h ) {
        $custom_field = $custom_field_e . '|' . $custom_field_h;

        //Valid IPN requests must have a custom field
        if ( empty( $custom_field_e ) || empty( $custom_field_h ) ) {
            $this->log_error( __METHOD__ . '(): IPN request does not have a custom field, so it was not created by Gravity Forms. Aborting.' );

            return false;
        }

        //Getting entry associated with this IPN message (entry id is sent in the 'custom' field)
        $entry_id     = $custom_field_e;
        $hash         = $custom_field_h;
        $hash_matches = wp_hash( $entry_id ) == $hash;

        //allow the user to do some other kind of validation of the hash
        $hash_matches = apply_filters( 'gform_tranzila_hash_matches', $hash_matches, $entry_id, $hash, $custom_field );

        //Validates that Entry Id wasn't tampered with
        if ( ! rgpost( 'test_ipn' ) && ! $hash_matches ) {
            $this->log_error( __METHOD__ . "(): Entry Id verification failed. Hash does not match. Custom field: {$custom_field}. Aborting." );

            return false;
        }

        $this->debug( __METHOD__ . "(): IPN message has a valid custom field: {$custom_field}" );

        $entry = GFAPI::get_entry( $entry_id );

        if ( is_wp_error( $entry ) ) {
            $this->log_error( __METHOD__ . '(): ' . $entry->get_error_message() );

            return false;
        }

        return $entry;
    }

    /**
     * Check if the callback is valid. If it does $this->callback() is gonna be processed.
     *
     * @return bool
     */
    public function is_callback_valid() {
        $signature = get_option( 'g2t_tranzila_notify_url_signature', '' );

        if ( rgget( 'page' ) != 'gf_tranzila_ipn' || rgget( 'signature' ) != $signature ) {
            return false;
        }

        return true;
    }

    //TODO move to admin functions section

    /**
     * Add supported notification events.
     *
     * @param array $form The form currently being processed.
     *
     * @return array|boolean
     */
    public function supported_notification_events( $form ) {
        if ( ! $this->has_feed( $form['id'] ) ) {
            return false;
        }

        return array(
            'complete_payment'          => esc_html__( 'Payment Completed', 'g2t' ),
            'refund_payment'            => esc_html__( 'Payment Refunded', 'g2t' ),
            'fail_payment'              => esc_html__( 'Payment Failed', 'g2t' ),
            'add_pending_payment'       => esc_html__( 'Payment Pending', 'g2t' ),
            'void_authorization'        => esc_html__( 'Authorization Voided', 'g2t' ),
            'create_subscription'       => esc_html__( 'Subscription Created', 'g2t' ),
            'cancel_subscription'       => esc_html__( 'Subscription Canceled', 'g2t' ),
            'expire_subscription'       => esc_html__( 'Subscription Expired', 'g2t' ),
            'add_subscription_payment'  => esc_html__( 'Subscription Payment Added', 'g2t' ),
            'fail_subscription_payment' => esc_html__( 'Subscription Payment Failed', 'g2t' ),
        );
    }

    /**
     * Check if the amount we get back from tranzila, and the amount we set as the initial amount (before the request to tranzila sent) is the same
     * (To the point of 4 zeros after the decimal)
     *
     * @param $entry_id
     * @param $amount_paid
     *
     * @return bool
     */
    private function is_valid_initial_payment_amount( $entry_id, $amount_paid ) {
        //get amount initially sent to tranzila
        $amount_sent = gform_get_meta( $entry_id, 'payment_amount' );
        if ( empty( $amount_sent ) ) {
            return true;
        }

        $epsilon    = 0.00001;
        $is_equal   = abs( floatval( $amount_paid ) - floatval( $amount_sent ) ) < $epsilon;
        $is_greater = floatval( $amount_paid ) > floatval( $amount_sent );

        //initial payment is valid if it is equal to or greater than product/subscription amount
        if ( $is_equal || $is_greater ) {
            return true;
        }

        return false;
    }

    /**
     * Add personal area page template.
     *
     * @param $template
     *
     * @return string
     */
    public function add_personal_area_page( $template ) {
        if ( is_page( 'g2t-personal-area' ) ) {
            $template = plugin_dir_path( __FILE__ ) . 'includes/g2t-personal-area.php';
        }


        return $template;
    }

    /**
     * Return the notify url that used to handles tranzila's response.
     *
     * @return string
     */
    public function get_notify_url() {
        $signature = get_option( 'g2t_tranzila_notify_url_signature' );

        if ( empty( $signature ) ) {
            $signature = wp_generate_password( 12, false );
            update_option( 'g2t_tranzila_notify_url_signature', $signature );
        }
        if ( is_ssl() ) {
            $home_url = home_url( '/', 'https' );
        } else {
            $home_url = home_url( '/' );
        }

        return add_query_arg( array( 'page' => 'gf_tranzila_ipn', 'signature' => $signature ), $home_url );
    }

    /**
     * Dynamically redirect the user back to the personal area after he was trying to update his credit card.
     */
    public function redirect_after_updating_cc() {
        if ( ! isset( $_POST['updating_cc'] ) || $_POST['updating_cc'] != '1' || rgget( 'page' ) == 'gf_tranzila_ipn' ) {
            return;
        }

        if ( $_POST['Response'] && $_POST['Response'] == '000' ) {
            wp_safe_redirect( get_site_url( null, 'g2t-personal-area?updated_cc=1' ) );
            die;
        }

        // failed to update cc card
        wp_safe_redirect( get_site_url( null, 'g2t-personal-area?updated_cc=0&response_code=' . isset( $_POST['Response'] ) ? $_POST['Response'] : '-1' ) );
        die;
    }

    /**
     * Uninstall the add-on, remove subscriptions that been scheduled.
     *
     * @return bool|void
     */
    public function uninstall() {

        $search_criteria['field_filters'] = array(
            array( 'key' => 'payment_status', 'value' => 'Active' ),
            array( 'key' => 'transaction_type', 'value' => '2' )
        );

        $entries = GFAPI::get_entries( 0, $search_criteria );

        if ( count( $entries ) > 0 ) {
            foreach ( $entries as $entry ) {

                $feeds = GFAPI::get_feeds( null, $entry['form_id'], 'g2t' );
                // for now, we don't support more then one tranzila's feed in a form
                if ( ! empty( $feeds ) && ! is_wp_error( $feeds ) ) {
                    $feed = $feeds[0];
                }

                if ( ! isset( $feed ) ) {
                    continue;
                }

                $entry_id = rgar( $entry, 'id' );
                $feed_id  = rgar( $feed, 'id' );

                // remove subscriptions scheduled hook
                if ( wp_next_scheduled( 'g2t_subscription_cron', array( $entry_id, $feed_id ) ) ) {
                    wp_clear_scheduled_hook( 'g2t_subscription_cron', array( $entry_id, $feed_id ) );
                }
            }
        }

        parent::uninstall();
    }

    /**
     * Add "Tranzila Username" column to feeds list.
     *
     * @return array
     */
    public function feed_list_columns() {
        return array_merge( parent::feed_list_columns(), array( 'tranzila_username' => __( 'Tranzila Username', 'g2t' ) ) );
    }

    /**
     * Render "Tranzila Username" column value.
     *
     * @param $feed
     *
     * @return mixed|null|string
     */
    public function get_column_value_tranzila_username( $feed ) {
        return rgars( $feed, 'meta/tranzilaUser' );
    }

    /**
     * Translate payment status.
     *
     * @param $status
     *
     * @return bool|string
     */
    public function translate_status( $status ) {
        switch ( $status ) {
            case 'Active':
                return __( 'Active', 'g2t' );
            case 'Cancelled':
                return __( 'Cancelled', 'g2t' );
            case 'Expired':
                return __( 'Expired', 'g2t' );
            case 'Processing':
                return __( 'Processing', 'g2t' );
            case 'Failed':
                return __( 'Failed', 'g2t' );
            default:
                return false;
        }
    }

    /**
     * Add new columns to entries export CSV.
     *
     * @hooked gform_export_fields
     *
     * @param $form
     *
     * @return mixed
     */
    public function add_custom_export_fields( $form ) {
        array_push( $form['fields'], array( 'id' => 'payments_so_far', 'label' => __( 'Payments So Far', 'g2t' ) ) );

        return $form;
    }

    /**
     * Set custom fields value on entries export.
     *
     * @hooked gform_export_field_value
     *
     * @param $value
     * @param $form_id
     * @param $field_id
     * @param $entry
     *
     * @return bool|mixed
     */
    public function set_custom_export_fields_values( $value, $form_id, $field_id, $entry ) {
        if ( $field_id == 'payments_so_far' ) {
            $payments_so_far = gform_get_meta( $entry['id'], 'payments_so_far' );
            if ( $payments_so_far ) {
                $value = $payments_so_far;
            }
        }

        return $value;
    }

    /**
     * Debugging the stuff
     *
     * @param $msg
     */
    protected function debug( $msg ) {
        if ( is_array( $msg ) || is_object( $msg ) ) {
            error_log( print_r( $msg, true ), 3, wp_upload_dir()['basedir'] . '/g2t-debug.log' );
        } else {
            error_log( $msg, 3, wp_upload_dir()['basedir'] . '/g2t-debug.log' );
        }
    }




    // TODO complete trial feature
    /*public function settings_trial_period( $field, $echo = true ) {
        //use the parent billing cycle function to make the drop down for the number and type
        $html = parent::settings_billing_cycle( $field );

        return $html;
    }*/
    /*public function set_trial_onchange( $field ) {
        //return the javascript for the onchange event
        return "
        if(jQuery(this).prop('checked')){
            jQuery('#{$field['name']}_product').show('slow');
            jQuery('#gaddon-setting-row-trialPeriod').show('slow');
            if (jQuery('#{$field['name']}_product').val() == 'enter_amount'){
                jQuery('#{$field['name']}_amount').show('slow');
            }
            else{
                jQuery('#{$field['name']}_amount').hide();
            }
        }
        else {
            jQuery('#{$field['name']}_product').hide('slow');
            jQuery('#{$field['name']}_amount').hide();
            jQuery('#gaddon-setting-row-trialPeriod').hide('slow');
        }";
    }*/


}

?>