<?php
/*
Plugin Name: Gravity Forms to Tranzila Add-On
Plugin URI: https://planwize.com
Description: Integrates Gravity Forms with Tranzila, enabling end users to purchase goods and services through Gravity Forms.
Version: 1.3.5
Author: Planwize
Author URI: https://planwize.com
Text Domain: g2t
Domain Path: /languages
*/

if ( !defined('GF_TRANZILA_VERSION') ) {
	define( 'GF_TRANZILA_VERSION', '1.3.5' );
}
if ( !defined('G2T_FILE') ) {
	define( 'G2T_FILE', __FILE__ );
}

if ( file_exists(plugin_dir_path( __FILE__) . 'vendor/autoload.php') ) {
	require 'vendor/autoload.php';
}

class G2T_Bootstrap {

	public static function load() {

		if ( ! method_exists( 'GFForms', 'include_payment_addon_framework' ) ) {
			return;
		}

		require_once( 'class-g2t.php' );

		require_once ('class-g2t-subscription.php');

		require_once ('includes/class-g2t-update-credit-card.php');

		GFAddOn::register( 'G2T' );
	}
}
add_action( 'gform_loaded', array( 'G2T_Bootstrap', 'load' ), 5 );

function gf_tranzila() {
	return G2T::get_instance();
}

/**
 * Add cron interval to support subscription payments.
 *
 * @param $schedules
 *
 * @return mixed
 */
function g2t_add_cron_intervals($schedules){

	// days
	for ( $i = 1; $i <= 100; $i++ ) {
		$schedules[$i . '_day'] = array(
			'interval' => 86400 * $i,
			'display' => sprintf(__( 'Every %d Day(s)', 'g2t' ), $i)
		);
	}

	// weeks
	for ( $i = 1; $i <= 100; $i++ ) {
		$schedules[$i . '_week'] = array(
			'interval' => 604800 * $i,
			'display' => sprintf(__( 'Every %d Week(s)', 'g2t' ), $i)
		);
	}

	// months
	for ( $i = 1; $i <= 100; $i++ ) {
		$schedules[$i . '_month'] = array(
			'interval' => 2628000 * $i,
			'display' => sprintf(__( 'Every %d Month(s)', 'g2t' ), $i)
		);
	}

	//years
	for ( $i = 1; $i <= 100; $i++ ) {
		$schedules[$i . '_year'] = array(
			'interval' => 31540000 * $i,
			'display' => sprintf(__( 'Every %d Year(s)', 'g2t' ), $i)
		);
	}

	// TODO just for testing, delete this
	$schedules['three_min'] = array(
		'interval' => 180,
		'display' => __( 'THREE MINUETS', 'g2t' )
	);
	$schedules['one_min'] = array(
		'interval' => 60,
		'display' => __( 'Every one minutes', 'g2t' )
	);

	return $schedules;
}
add_filter( 'cron_schedules', 'g2t_add_cron_intervals' );


/**
 * Runs on plugin activation.
 */
function g2t_activation() {
	// schedule daily event for credit cards expiration date checks
	if ( ! wp_next_scheduled('g2t_check_expdates') ) {
		wp_schedule_event(time(), '1_month', 'g2t_check_expdates');
	}
}

/**
 * Runs on plugin deactivation.
 */
function g2t_deactivation() {
	if ( wp_next_scheduled('g2t_check_expdates') ){
		wp_clear_scheduled_hook('g2t_check_expdates');
	}
}

// plugins activation/deactivation
register_activation_hook(__FILE__, 'g2t_activation');
register_deactivation_hook(__FILE__, 'g2t_deactivation');